import os
import subprocess
from pathlib import Path
import sys
import traceback

# FastConnect.exe (PyInstaller) already contains the app and its requirements
FROZEN = getattr(sys, "frozen", False)

if FROZEN:
    # Keep user data (fc_data.json, generated files) next to the exe
    os.chdir(os.path.dirname(sys.executable))
else:
    HERE = Path(__file__).resolve().parent

    # The downloaded ZIP has everything in one folder; the repo keeps the app in ../App
    APP_DIR = HERE if (HERE / "gui.py").exists() else HERE.parent / "App"

    if str(APP_DIR) not in sys.path:
        sys.path.insert(0, str(APP_DIR))

    install_file = APP_DIR / "install.txt"
    requirements = APP_DIR / "requirements.txt"


def read_file(file_path):
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return "Not Installed"


def install_requirements():
    print("Installing Fast Connect requirements...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(requirements)],
        capture_output=True, text=True,
    )
    print("Output:\n", result.stdout)

    if result.returncode != 0:
        print("Error:\n", result.stderr)
        sys.exit(result.returncode)

    install_file.write_text("Installed", encoding="utf-8")


def self_test():
    """--self-test: check every part of the app loads, without opening the UI (used by the build)."""
    try:
        import socket
        import threading
        import tkinter as tk
        import gui, ai, app_icon, accounts_api
        from secure_channel import SecureChannel

        ai.AI()

        # The encrypted chat connection works end to end
        a, b = socket.socketpair()
        a.settimeout(1.0)
        b.settimeout(1.0)
        server_side, client_side = SecureChannel(a, True), SecureChannel(b, False)
        thread = threading.Thread(target=server_side.handshake)
        thread.start()
        client_side.handshake()
        thread.join()
        client_side.send("self-test")
        assert server_side.recv() == "self-test", "encrypted channel failed"

        # A shipped build must contain no keys at all
        if FROZEN or APP_DIR == HERE:
            here = Path(sys.executable).parent if FROZEN else HERE
            for name in ("secrets.enc", "secrets.local.json", "gdrive_credentials.json"):
                assert not list(here.rglob(name)), f"this build contains {name}"

        root = tk.Tk()
        app_icon.apply(root)
        root.destroy()
        print("accounts server:", "configured" if accounts_api.API_URL else "NOT configured (guests only)")
    except Exception:
        Path("self-test.log").write_text(traceback.format_exc(), encoding="utf-8")
        sys.exit(1)
    sys.exit(0)


if not FROZEN and read_file(install_file) != "Installed":
    install_requirements()

if "--self-test" in sys.argv:
    self_test()

# Import only after the requirements are installed
from gui import main

main()
