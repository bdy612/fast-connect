@echo off
setlocal
title Fast Connect 1.1 Installer
cd /d "%~dp0"

echo ========================================
echo   Fast Connect 1.1 - Installer
echo ========================================
echo.

REM Find Python 3.10 or newer (the "py" launcher first, then "python")
set "PY="
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1 && set "PY=python"
set "LOCAL_PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY if exist "%LOCAL_PY%" set PY="%LOCAL_PY%"
if not defined PY goto getpython

:havepython
echo Using:
%PY% --version
echo.

echo [1/3] Creating virtual environment...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
if errorlevel 1 goto fail

echo [2/3] Installing requirements (this can take a minute)...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
> install.txt echo Installed
echo.

echo [3/3] Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d='%~dp0'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Fast Connect.lnk'); $s.TargetPath=$d+'.venv\Scripts\pythonw.exe'; $s.Arguments=[char]34+$d+'run.py'+[char]34; $s.WorkingDirectory=$d; $s.Description='Fast Connect 1.1'; if(Test-Path ($d+'Icon.ico')){$s.IconLocation=$d+'Icon.ico'}; $s.Save()"
if errorlevel 1 (
    echo WARNING: Could not create the desktop shortcut.
) else (
    echo Desktop shortcut "Fast Connect" created.
)
echo.

echo ========================================
echo   Installation complete!
echo ========================================
echo Start Fast Connect any time from the "Fast Connect" desktop shortcut.
echo Launching now...
start "" ".venv\Scripts\pythonw.exe" "%~dp0run.py"
timeout /t 5 >nul
exit /b 0

:getpython
REM No Python 3.10+ - install the official one from python.org for this user only (no admin needed)
set "PY_ARCH=amd64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "PY_ARCH=arm64"
set "PY_SETUP=%TEMP%\fast-connect-python-setup.exe"
echo Python is not installed yet. Downloading it from python.org (about 25 MB)...
curl.exe -fL --progress-bar -o "%PY_SETUP%" "https://www.python.org/ftp/python/3.12.10/python-3.12.10-%PY_ARCH%.exe"
if errorlevel 1 goto nopython
REM Only run the installer if it really is signed by the Python Software Foundation
powershell -NoProfile -Command "$s = Get-AuthenticodeSignature -LiteralPath $env:PY_SETUP; if ($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'Python Software Foundation') { exit 1 }"
if errorlevel 1 (
    del "%PY_SETUP%" >nul 2>&1
    echo The downloaded Python installer failed its signature check and was deleted.
    goto nopython
)
echo Installing Python, this takes a minute...
"%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=0 Include_test=0
set "PY_RESULT=%errorlevel%"
del "%PY_SETUP%" >nul 2>&1
if not "%PY_RESULT%"=="0" goto nopython
if not exist "%LOCAL_PY%" goto nopython
set PY="%LOCAL_PY%"
echo Python installed.
echo.
goto havepython

:nopython
echo ERROR: Python could not be installed automatically.
echo.
echo 1. Install Python from https://www.python.org/downloads/
echo 2. On the first installer screen, tick "Add python.exe to PATH"
echo 3. Run install.bat again
echo.
start "" "https://www.python.org/downloads/"
pause
exit /b 1

:fail
echo.
echo ERROR: Installation failed. Check your internet connection and the messages above,
echo then run install.bat again.
pause
exit /b 1
