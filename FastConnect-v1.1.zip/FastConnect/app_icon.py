"""
Window / taskbar / Dock icon for every Fast Connect window.
"""

import os
import sys
from functools import lru_cache
from PIL import Image, ImageTk

ICON_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Icon.png")
APP_ID = "FastConnect.App.1.1"
WM_CLASS = "FastConnect"  # Tk reports it as "Fastconnect" - matches StartupWMClass in the Linux .desktop file


@lru_cache(maxsize=None)
def _artwork():
    """Icon.png cropped to the visible artwork and made square.

    The source image has a wide transparent border, which makes it tiny
    when it is scaled down to taskbar / title bar size.
    """
    image = Image.open(ICON_FILE).convert("RGBA")
    visible = image.getchannel("A").point(lambda a: 255 if a > 40 else 0).getbbox()
    if visible:
        image = image.crop(visible)
    side = max(image.size)
    square = Image.new("RGBA", (side, side))
    square.paste(image, ((side - image.width) // 2, (side - image.height) // 2))
    return square


def load_icon_image(size=256):
    """Return the app icon as a square RGBA image of the given size."""
    return _artwork().resize((size, size), Image.LANCZOS)


def set_windows_app_id():
    """Give the process its own taskbar identity so Windows shows our icon, not Python's.

    Must run before the first window is created.
    """
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass


def apply(root):
    """Set the icon on a Tk root window (and every window it opens)."""
    try:
        photos = [ImageTk.PhotoImage(load_icon_image(s), master=root) for s in (256, 64, 32, 16)]
        root.iconphoto(True, *photos)
        root._fast_connect_icons = photos  # keep references so Tk doesn't lose the images
    except Exception as e:
        print(f"[icon] Could not set window icon: {e}")
