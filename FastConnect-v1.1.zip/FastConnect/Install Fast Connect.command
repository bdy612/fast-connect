#!/usr/bin/env bash
# macOS: double-click this file to install Fast Connect
cd "$(dirname "$0")"
exec bash install.sh
