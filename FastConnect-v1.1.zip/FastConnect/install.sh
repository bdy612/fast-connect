#!/usr/bin/env bash
# Fast Connect 1.1 installer for macOS and Linux.
# Double-click it (Linux) or "Install Fast Connect.command" (macOS) - no typing needed.

cd "$(dirname "$0")"
DIR="$(pwd)"
OS="$(uname -s)"
APP_NAME="Fast Connect"
MAC_PYTHON_URL="https://www.python.org/ftp/python/3.12.10/python-3.12.10-macos11.pkg"

# --- Make sure we're running in a visible terminal --------------------------
# File managers start scripts without a window, so reopen ourselves in one.
if [ ! -t 1 ] && [ "$1" != "--in-terminal" ] && [ "$OS" = "Linux" ]; then
    for term in x-terminal-emulator gnome-terminal kgx ptyxis konsole xfce4-terminal mate-terminal tilix kitty alacritty xterm; do
        command -v "$term" >/dev/null 2>&1 || continue
        case "$term" in
            gnome-terminal|kgx|ptyxis) "$term" -- bash "$DIR/install.sh" --in-terminal && exit 0 ;;
            xfce4-terminal|mate-terminal) "$term" -x bash "$DIR/install.sh" --in-terminal && exit 0 ;;
            *) "$term" -e bash "$DIR/install.sh" --in-terminal && exit 0 ;;
        esac
    done
    # No terminal found - carry on without one
fi

# Keep our own terminal window open at the end so messages can be read
if [ "$1" = "--in-terminal" ]; then
    trap 'echo; read -r -p "Press Enter to close this window..." _' EXIT
fi

fail() {
    echo
    echo "ERROR: $1"
    exit 1
}

ask() {
    # ask "question" -> returns 0 for yes (default), 1 for no
    local reply
    read -r -p "$1 [Y/n] " reply
    case "$reply" in [nN]*) return 1 ;; *) return 0 ;; esac
}

echo "========================================"
echo "  $APP_NAME 1.1 - Installer"
echo "========================================"
echo

# --- Find Python 3.10+ with tkinter ------------------------------------------
python_ok() {
    "$1" -c 'import sys, tkinter; sys.exit(sys.version_info < (3, 10))' >/dev/null 2>&1
}

find_python() {
    local cands=()
    if [ "$OS" = "Darwin" ]; then
        # python.org and Homebrew installs; /usr/bin/python3 only if the developer tools exist
        # (otherwise running it pops up an "install developer tools" dialog)
        for p in /Library/Frameworks/Python.framework/Versions/3.*/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
            [ -x "$p" ] && cands+=("$p")
        done
        xcode-select -p >/dev/null 2>&1 && cands+=(python3)
    else
        cands=(python3 python3.14 python3.13 python3.12 python3.11 python3.10)
    fi
    for c in "${cands[@]}"; do
        if command -v "$c" >/dev/null 2>&1 && python_ok "$c"; then
            echo "$c"
            return 0
        fi
    done
    return 1
}

install_python_mac() {
    echo "Python 3.10+ is needed. Downloading the official installer from python.org..."
    local pkg="/tmp/fast-connect-python.pkg"
    curl -fL --progress-bar -o "$pkg" "$MAC_PYTHON_URL" || fail "Could not download Python. Check your internet connection."
    echo
    echo "The Python installer is opening - click Continue / Install in its window."
    echo "This installer will carry on by itself when Python is ready..."
    open -W "$pkg"
    rm -f "$pkg"
}

install_python_linux() {
    local pkgs cmd
    if command -v apt-get >/dev/null 2>&1; then
        pkgs="python3 python3-venv python3-pip python3-tk"
        cmd="sudo apt-get update && sudo apt-get install -y $pkgs"
    elif command -v dnf >/dev/null 2>&1; then
        pkgs="python3 python3-pip python3-tkinter"
        cmd="sudo dnf install -y $pkgs"
    elif command -v pacman >/dev/null 2>&1; then
        pkgs="python python-pip tk"
        cmd="sudo pacman -S --needed --noconfirm $pkgs"
    elif command -v zypper >/dev/null 2>&1; then
        pkgs="python3 python3-pip python3-tk"
        cmd="sudo zypper install -y $pkgs"
    else
        fail "Please install Python 3.10+ with Tkinter using your software center, then run this installer again."
    fi
    echo "Fast Connect needs these system packages: $pkgs"
    ask "Install them now? (you'll be asked for your password)" || fail "Python 3.10+ with Tkinter is required."
    bash -c "$cmd" || fail "Could not install the system packages."
}

PY="$(find_python)"
if [ -z "$PY" ]; then
    if [ "$OS" = "Darwin" ]; then install_python_mac; else install_python_linux; fi
    PY="$(find_python)" || fail "Python 3.10+ with Tkinter still wasn't found. Restart your computer and run the installer again."
fi
echo "Using: $("$PY" --version)"

# --- Private environment + requirements --------------------------------------
echo "[1/3] Creating a private Python environment..."
if [ ! -x ".venv/bin/python" ] && ! "$PY" -m venv .venv >/dev/null 2>&1; then
    rm -rf .venv
    if command -v apt-get >/dev/null 2>&1; then
        # Debian/Ubuntu ship venv support as a separate package
        ver="$("$PY" -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
        echo "Python's venv support is missing (package python$ver-venv)."
        ask "Install it now? (you'll be asked for your password)" || fail "python$ver-venv is required."
        sudo apt-get install -y "python$ver-venv" || sudo apt-get install -y python3-venv || fail "Could not install python$ver-venv."
    fi
    "$PY" -m venv .venv || fail "Could not create the Python environment."
fi

echo "[2/3] Installing requirements (this can take a minute)..."
.venv/bin/python -m pip install --upgrade pip >/dev/null 2>&1
.venv/bin/python -m pip install -r requirements.txt || fail "Could not install the requirements. Check your internet connection and try again."
echo "Installed" > install.txt

# --- Launcher with the app icon ----------------------------------------------
echo "[3/3] Adding $APP_NAME to your apps..."
cat > start.sh <<EOF
#!/usr/bin/env bash
cd "$DIR"
exec "$DIR/.venv/bin/python" "$DIR/run.py"
EOF
chmod +x start.sh

if [ "$OS" = "Darwin" ]; then
    APP="$HOME/Applications/$APP_NAME.app"
    rm -rf "$APP"
    mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
    cat > "$APP/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>$APP_NAME</string>
    <key>CFBundleDisplayName</key><string>$APP_NAME</string>
    <key>CFBundleIdentifier</key><string>app.fastconnect.desktop</string>
    <key>CFBundleVersion</key><string>1.1</string>
    <key>CFBundleShortVersionString</key><string>1.1</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleExecutable</key><string>FastConnect</string>
    <key>CFBundleIconFile</key><string>FastConnect</string>
</dict>
</plist>
EOF
    printf '#!/usr/bin/env bash\nexec "%s/start.sh"\n' "$DIR" > "$APP/Contents/MacOS/FastConnect"
    chmod +x "$APP/Contents/MacOS/FastConnect"
    # Build the .icns app icon with macOS's own tools
    if [ -f icon-256.png ]; then
        ICONSET="$(mktemp -d)/FastConnect.iconset"
        mkdir -p "$ICONSET"
        for size in 16 32 128 256; do
            sips -z $size $size icon-256.png --out "$ICONSET/icon_${size}x${size}.png" >/dev/null 2>&1
            [ $size -le 128 ] && sips -z $((size * 2)) $((size * 2)) icon-256.png --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null 2>&1
        done
        iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/FastConnect.icns" 2>/dev/null
        rm -rf "$(dirname "$ICONSET")"
    fi
    touch "$APP"   # make Finder pick up the icon
    ln -sfn "$APP" "$HOME/Desktop/$APP_NAME"
    echo "Added \"$APP_NAME\" to your Applications folder and Desktop."
else
    ICON="$DIR/icon-256.png"
    [ -f "$ICON" ] || ICON="$DIR/Icon.png"
    APPS="$HOME/.local/share/applications"
    mkdir -p "$APPS"
    cat > "$APPS/fast-connect.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$APP_NAME
Comment=Encrypted chat with the FastAI assistant
Exec="$DIR/start.sh"
Icon=$ICON
Terminal=false
Categories=Network;Chat;
StartupWMClass=Fastconnect
EOF
    chmod +x "$APPS/fast-connect.desktop"

    # Desktop shortcut, marked as trusted so it can be launched straight away
    DESKTOP="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
    if [ -d "$DESKTOP" ]; then
        cp "$APPS/fast-connect.desktop" "$DESKTOP/fast-connect.desktop"
        chmod +x "$DESKTOP/fast-connect.desktop"
        gio set "$DESKTOP/fast-connect.desktop" metadata::trusted true >/dev/null 2>&1 || true
    fi
    echo "Added $APP_NAME to your applications menu and Desktop."
fi

echo
echo "========================================"
echo "  Installation complete!"
echo "========================================"
echo "Launching $APP_NAME..."
if [ "$OS" = "Darwin" ]; then
    open "$APP"
else
    nohup "$DIR/start.sh" >/dev/null 2>&1 &
fi
