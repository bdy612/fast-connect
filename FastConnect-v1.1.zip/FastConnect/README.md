# Fast Connect

**Version:** 1.1
**Date:** October 1, 2026
**Requirements:** Python 3.10+ (with tkinter) and an internet connection for FastAI and cloud accounts

## Overview
A feature-rich, multi-layered encrypted chat application with hosting capabilities, private direct messaging, persistent cloud storage, and an integrated **FastAI Desktop Assistant** powered by Google Gemini.

---

## Installation

Unzip `FastConnect-v1.1.zip` somewhere permanent (e.g. Documents), then:

- **Windows:** the easiest way is `FastConnect-Setup-v1.1.exe` from the website (Python built in).
  From this ZIP, double-click `install.bat`; if Python is missing it downloads and installs it for you.
- **macOS:** double-click `Install Fast Connect`. If you don't have Python, it downloads and opens the official
  installer for you. If macOS blocks the file, go to *System Settings → Privacy & Security → Open Anyway*.
- **Linux:** right-click `install.sh` → *Run as a Program* (or double-click → *Run*). If Python or Tkinter
  is missing, it offers to install them and asks for your password.

The installer creates a private Python environment, installs the requirements, adds a **Fast Connect**
shortcut with the app icon (Desktop, plus Applications on macOS and the app menu on Linux) and starts the app.

**Troubleshooting**
- *Python couldn't be installed (Windows)* – install it from https://www.python.org/downloads/ with
  "Add python.exe to PATH" ticked, then rerun the installer.
- *install.sh opens in a text editor (Linux)* – right-click → *Properties → Permissions* → tick
  *Allow executing file as program*, then *Run as a Program*.
- *Network errors* – check your internet connection and rerun the installer; it is safe to run more than once.
- *Shortcut stopped working* – you probably moved the folder; run the installer again from the new location.

---

## Features

- **Encrypted connections**: every connection to a chat server is encrypted with AES-256-GCM after an ECDH key exchange, and the server verifies each user's identity with a one-time login ticket.
- **Multi-Layered Vigenère Encryption**: multi-pass encryption on top, for server broadcasts and private direct messages.
- **FastAI Desktop Assistant (Beta)**:
  - Text-based AI chat powered by Gemini models (`gemini-2.5-flash`, `gemini-2.5-pro`).
  - Image understanding (`.jpg`, `.png`, `.webp`) and AI image generation.
  - Video content analysis and audio synthesis integration.
- **☁️ Cloud Persistence & Authentication**:
  - Secure account registration and login. Passwords are stored as salted PBKDF2-SHA256 hashes.
  - Profiles and friend lists are kept in the cloud by the Fast Connect accounts server; the app holds no Google keys.
- **Socket-Based Networking**:
  - Custom TCP server/client architecture using binary length-prefixed framing (`struct.pack('>I', len)`) for high connection stability.
  - Multi-threaded server listening and message distribution.
- **Modern Dark Tkinter GUI**: Tabbed desktop application covering Host/Setup, User Management, Private DMs, Network Broadcasts, and FastAI Assistant.

---

## 💡 Usage Overview

- **Users & Friends**: Search for connected users, send friend requests, and accept pending requests.
- **Private Messaging**: Double-click any friend in your list to open an encrypted 1-on-1 direct message window.
- **Server Broadcasts**: Send encrypted messages to all users currently connected to the server.
- **FastAI Assistant**: Open the AI tab to ask questions, attach images or videos for analysis, generate voice outputs, or synthesize new images.

---

## 🛡️ License
Distributed under the MIT License. See `LICENSE` for more information.
Copyright © 2026 Fast Connect