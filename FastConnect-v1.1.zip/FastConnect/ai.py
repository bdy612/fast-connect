import base64
import mimetypes
import os
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import accounts_api

MAX_FILE_BYTES = 15 * 1024 * 1024   # images and videos are sent inline through the backend
MAX_HISTORY = 39                    # earlier chat turns sent with each new message


class AI:
    """FastAI. Requests go through the Fast Connect backend, which holds the Gemini key
    and each account's daily allowance, so no key ships with the app."""

    def __init__(self):
        self.flash = "gemini-3.8-flash"
        self.weak_flash = "gemini-3.6-flash"
        self.pro = "gemini-3.1-pro-preview"
        self.flash_lite = "gemini-3.5-flash-lite"
        self.model = self.flash_lite

        self.image = "nano-banana-pro-preview"
        self.voice = "lyria-3.5"
        self.video = "gemini-omni-1.1-flash"

        self.units_left = None
        self.setup()

    def setComplex(self):
        if self.model == self.flash:
            self.model = self.pro

        elif self.model == self.pro:
            self.model = self.weak_flash

        elif self.model == self.weak_flash:
            self.model = self.flash_lite

        elif self.model == self.flash_lite:
            self.model = self.flash

        else:
            self.model = self.flash

        self.setup()  # a new model starts a new conversation
        return self.model

    def setup(self):
        self.history = []

    def _send(self, kind, model, contents):
        result = accounts_api.ai(kind, model, contents)
        if not result.get("ok"):
            raise RuntimeError(result.get("error", "FastAI failed."))
        self.units_left = result.get("units_left")
        return result

    @staticmethod
    def _file_part(file_path):
        if os.path.getsize(file_path) > MAX_FILE_BYTES:
            raise RuntimeError(f"That file is too large for FastAI (max {MAX_FILE_BYTES // (1024 * 1024)} MB).")
        mime = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        with open(file_path, "rb") as f:
            data = base64.b64encode(f.read()).decode("ascii")
        return {"inlineData": {"mimeType": mime, "data": data}}

    @staticmethod
    def _save_media(result, default_name):
        """Save the first returned image/audio to the current folder; returns its path or None."""
        for item in result.get("media", []):
            ext = mimetypes.guess_extension(item.get("mimeType", "")) or os.path.splitext(default_name)[1]
            path = os.path.splitext(default_name)[0] + ext
            with open(path, "wb") as f:
                f.write(base64.b64decode(item["data"]))
            return path
        return None

    def ask(self, prompt):
        turn = {"role": "user", "parts": [{"text": prompt}]}
        result = self._send("chat", self.model, self.history[-MAX_HISTORY:] + [turn])
        self.history += [turn, {"role": "model", "parts": [{"text": result.get("text", "")}]}]
        return result.get("text", "")

    def read(self, prompt, file_path=None):
        if not file_path:
            file_path = filedialog.askopenfilename(
                title="Select an Image for Gemini",
                filetypes=[("Image Files", "*.jpg *.jpeg *.png *.webp")],
            )
            if not file_path:
                return "No file selected"

        contents = [{"role": "user", "parts": [self._file_part(file_path), {"text": prompt}]}]
        return self._send("image", self.model, contents).get("text", "")

    def generate_image(self, prompt):
        """Generates an image using the image model; returns the saved file's path."""
        result = self._send("imageGen", self.image, [{"role": "user", "parts": [{"text": prompt}]}])
        return self._save_media(result, "generated_output.png")

    def generate_voice(self, prompt):
        """Generates audio using the voice model; returns the saved file's path, or the text answer."""
        result = self._send("voice", self.voice, [{"role": "user", "parts": [{"text": prompt}]}])
        return self._save_media(result, "generated_audio.mp3") or result.get("text", "")

    def analyze_video(self, prompt):
        """Analyzes a video file using the video model."""
        file_path = filedialog.askopenfilename(
            title="Select a Video File",
            filetypes=[("Video Files", "*.mp4 *.avi *.mov *.mkv")],
        )
        if not file_path:
            return "No video file selected"

        contents = [{"role": "user", "parts": [self._file_part(file_path), {"text": prompt}]}]
        return self._send("video", self.video, contents).get("text", "")


class FastAIGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("FastAI Desktop Assistant")
        self.root.geometry("650x600")
        self.root.minsize(500, 450)
        
        # Modern Dark Color Palette
        self.COLOR_BG = "#1e1e2e"          # Main Window Background
        self.COLOR_PANEL = "#252538"       # Top & Bottom Toolbars
        self.COLOR_CHAT_BG = "#181825"     # Chat Log Display Background
        self.COLOR_USER_TXT = "#89b4fa"    # User Text Color (Blue Accent)
        self.COLOR_BOT_TXT = "#cdd6f4"     # Bot Text Color (Off-white)
        self.COLOR_SYS_TXT = "#a6adc8"     # System Status Text Color (Muted Gray)
        self.COLOR_BTN_BG = "#313244"      # Icon/Tool Button Background
        self.COLOR_BTN_FG = "#cdd6f4"      # Button Text/Icon Color
        self.COLOR_ACCENT = "#89b4fa"      # Accent Blue for Primary Action
        self.COLOR_ACCENT_FG = "#11111b"   # Accent Text Color
        self.COLOR_ENTRY_BG = "#313244"    # Entry Input Background
        
        self.root.configure(bg=self.COLOR_BG)
        self.ai_backend = AI()

        # --- Top Bar ---
        self.top_frame = tk.Frame(root, pady=6, bg=self.COLOR_PANEL)
        self.top_frame.pack(fill=tk.X)

        self.model_btn = tk.Button(
            self.top_frame, 
            text=f"Model: {self.ai_backend.model}", 
            command=self.toggle_model,
            bg=self.COLOR_BTN_BG, 
            fg=self.COLOR_BTN_FG,
            activebackground="#45475a",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            font=("Arial", 9, "bold"),
            padx=10,
            pady=3
        )
        self.model_btn.pack(side=tk.LEFT, padx=15)

        # --- Chat Display Area ---
        self.chat_display = scrolledtext.ScrolledText(
            root, 
            wrap=tk.WORD, 
            font=("Arial", 10), 
            state=tk.DISABLED, 
            bg=self.COLOR_CHAT_BG,
            fg=self.COLOR_BOT_TXT,
            insertbackground="#ffffff",
            relief=tk.FLAT,
            highlightthickness=0
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)
        
        # Configure Right (User), Left (Bot), and Center (System) Text Tags
        self.chat_display.tag_configure(
            "user", 
            justify="right", 
            rmargin=15, 
            lmargin1=100, 
            lmargin2=100, 
            foreground=self.COLOR_USER_TXT
        )
        self.chat_display.tag_configure(
            "bot", 
            justify="left", 
            lmargin1=15, 
            lmargin2=15, 
            rmargin=100, 
            foreground=self.COLOR_BOT_TXT
        )
        self.chat_display.tag_configure(
            "system", 
            justify="center", 
            foreground=self.COLOR_SYS_TXT
        )

        self.append_to_chat("bot", "Hello! I am FastAI. How can I help you today?")

        # --- Bottom Input & Action Bar ---
        self.bottom_frame = tk.Frame(root, pady=8, bg=self.COLOR_PANEL)
        self.bottom_frame.pack(fill=tk.X, side=tk.BOTTOM)

        # Icon action buttons frame
        self.action_frame = tk.Frame(self.bottom_frame, bg=self.COLOR_PANEL)
        self.action_frame.pack(side=tk.LEFT, padx=(15, 5))

        btn_kwargs = {
            "font": ("Arial", 12),
            "width": 3,
            "bg": self.COLOR_BTN_BG,
            "fg": self.COLOR_BTN_FG,
            "activebackground": "#45475a",
            "activeforeground": "#ffffff",
            "relief": tk.FLAT,
            "bd": 0
        }

        # 🖼️ Image Upload
        self.img_btn = tk.Button(self.action_frame, text="🖼️", command=self.handle_image_prompt, **btn_kwargs)
        self.img_btn.pack(side=tk.LEFT, padx=2)

        # 🎨 Image Generation
        self.gen_img_btn = tk.Button(self.action_frame, text="🎨", command=self.handle_image_generation, **btn_kwargs)
        self.gen_img_btn.pack(side=tk.LEFT, padx=2)

        # 🎙️ Voice Generation
        self.voice_btn = tk.Button(self.action_frame, text="🎙️", command=self.handle_voice_generation, **btn_kwargs)
        self.voice_btn.pack(side=tk.LEFT, padx=2)

        # 🎥 Video Analysis
        self.video_btn = tk.Button(self.action_frame, text="🎥", command=self.handle_video_prompt, **btn_kwargs)
        self.video_btn.pack(side=tk.LEFT, padx=2)

        # Text Input Entry
        self.input_entry = tk.Entry(
            self.bottom_frame, 
            font=("Arial", 11),
            bg=self.COLOR_ENTRY_BG,
            fg="#ffffff",
            insertbackground="#ffffff",
            relief=tk.FLAT,
            bd=5
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.input_entry.bind("<Return>", lambda event: self.handle_text_prompt())

        # Send Button
        self.send_btn = tk.Button(
            self.bottom_frame, 
            text="➔", 
            font=("Arial", 11, "bold"),
            width=4, 
            command=self.handle_text_prompt,
            bg=self.COLOR_ACCENT, 
            fg=self.COLOR_ACCENT_FG,
            activebackground="#b4befe",
            activeforeground="#11111b",
            relief=tk.FLAT,
            bd=0
        )
        self.send_btn.pack(side=tk.RIGHT, padx=(0, 15))

    def toggle_model(self):
        new_model = self.ai_backend.setComplex()
        self.model_btn.config(text=f"Model: {new_model}")
        self.append_to_chat("system", f"--- Switched active model to {new_model} ---")

    def append_to_chat(self, sender_type, text):
        self.chat_display.config(state=tk.NORMAL)
        
        if sender_type == "user":
            self.chat_display.insert(tk.END, f"You\n{text}\n\n", "user")
        elif sender_type == "bot":
            self.chat_display.insert(tk.END, f"FastAI\n{text}\n\n", "bot")
        else:
            self.chat_display.insert(tk.END, f"{text}\n\n", "system")

        self.chat_display.config(state=tk.DISABLED)
        self.chat_display.yview(tk.END)

    def handle_text_prompt(self):
        prompt = self.input_entry.get().strip()
        if not prompt:
            return
        
        self.input_entry.delete(0, tk.END)
        self.append_to_chat("user", prompt)
        
        try:
            reply = self.ai_backend.ask(prompt)
            self.append_to_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Failed to get response: {e}")

    def handle_image_prompt(self):
        prompt = self.input_entry.get().strip() or "Describe this image in detail."
        self.input_entry.delete(0, tk.END)

        self.append_to_chat("user", f"[Sent Image] Prompt: '{prompt}'")
        try:
            reply = self.ai_backend.read(prompt)
            if reply == "No file selected":
                self.append_to_chat("system", "Image selection canceled.")
            else:
                self.append_to_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Failed to analyze image: {e}")

    def handle_image_generation(self):
        prompt = self.input_entry.get().strip()
        if not prompt:
            messagebox.showinfo("Input Needed", "Please type an image prompt in the text box first.")
            return

        self.input_entry.delete(0, tk.END)
        self.append_to_chat("user", f"[Generate Image Request] {prompt}")

        try:
            file_path = self.ai_backend.generate_image(prompt)
            if file_path:
                self.append_to_chat("bot", f"Image generated successfully! Saved to '{file_path}'.")
            else:
                self.append_to_chat("bot", "Could not generate image.")
        except Exception as e:
            messagebox.showerror("API Error", f"Failed to generate image: {e}")

    def handle_voice_generation(self):
        prompt = self.input_entry.get().strip()
        if not prompt:
            messagebox.showinfo("Input Needed", "Please type text to convert to voice in the text box.")
            return

        self.input_entry.delete(0, tk.END)
        self.append_to_chat("user", f"[Voice Request] {prompt}")

        try:
            result = self.ai_backend.generate_voice(prompt)
            self.append_to_chat("bot", f"Voice generated: {result}")
        except Exception as e:
            messagebox.showerror("API Error", f"Failed to generate voice: {e}")

    def handle_video_prompt(self):
        prompt = self.input_entry.get().strip() or "Summarize what happens in this video."
        self.input_entry.delete(0, tk.END)

        self.append_to_chat("user", f"[Sent Video] Prompt: '{prompt}'")
        try:
            reply = self.ai_backend.analyze_video(prompt)
            if reply == "No video file selected":
                self.append_to_chat("system", "Video selection canceled.")
            else:
                self.append_to_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Failed to analyze video: {e}")


if __name__ == "__main__":
    app_root = tk.Tk()
    gui = FastAIGUI(app_root)
    app_root.mainloop()