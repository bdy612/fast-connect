import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, scrolledtext
import threading
from ai import AI
from fast_connect import FastConnect
import app_icon
import accounts_api
import ctypes
from PIL import ImageTk, Image
import os
import sys

script_dir = os.path.abspath(os.path.dirname(__file__))
current_dir = script_dir

while True:
    if os.path.basename(current_dir) == "Fast_Connect":
        config_path = os.path.dirname(current_dir)
        if config_path not in sys.path:
            sys.path.insert(0, config_path)
        break
        
    parent_dir = os.path.dirname(current_dir)
    
    if parent_dir == current_dir:
        print("Warning: 'Fast_Connect' directory not found in the path hierarchy.")
        fallback_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        if fallback_path not in sys.path:
            sys.path.insert(0, fallback_path)
        break
        
    current_dir = parent_dir

class FastConnectGUI:
    """Comprehensive GUI for FastConnect with friend requests and private chats"""

    def __init__(self, root, username=None, real_name=None, user_number=None):
        self.root = root
        self.root.title("Fast Connect - Friend Network")
        self.root.geometry("900x800")
        app_icon.apply(self.root)
        self.fc = FastConnect()
        self.ai = AI()

        # Apply credentials that came from the login window
        if username:
            self.fc.username = username
            self.fc.real_name = real_name or ''
            self.root.title(f"Fast Connect - {username}")
            if hasattr(self.fc, '_save_data'):
                self.fc._save_data()
        self._user_number = user_number

        # Chat windows for private messages
        self.chat_windows = {}

        # Theme color definitions (Updated colors)
        self.COLOR_BG = getattr(self, "COLOR_BG", "#0f172a")
        self.COLOR_PANEL = getattr(self, "COLOR_PANEL", "#1e293b")
        self.COLOR_BTN_BG = getattr(self, "COLOR_BTN_BG", "#334155")
        self.COLOR_BTN_FG = getattr(self, "COLOR_BTN_FG", "#f8fafc")
        self.COLOR_CHAT_BG = getattr(self, "COLOR_CHAT_BG", "#020617")
        self.COLOR_BOT_TXT = getattr(self, "COLOR_BOT_TXT", "#f8fafc")
        self.COLOR_USER_TXT = getattr(self, "COLOR_USER_TXT", "#38bdf8")
        self.COLOR_SYS_TXT = getattr(self, "COLOR_SYS_TXT", "#f59e0b")
        self.COLOR_ENTRY_BG = getattr(self, "COLOR_ENTRY_BG", "#1e293b")
        self.COLOR_ACCENT = getattr(self, "COLOR_ACCENT", "#0284c7")
        self.COLOR_ACCENT_FG = getattr(self, "COLOR_ACCENT_FG", "#ffffff")

        # Configure style
        style = ttk.Style()
        style.theme_use('clam')

        # Customizing ttk widget styles for the new theme
        style.configure(".", background=self.COLOR_BG, foreground=self.COLOR_BTN_FG)
        style.configure("TFrame", background=self.COLOR_BG)
        style.configure("TLabelframe", background=self.COLOR_BG, foreground=self.COLOR_ACCENT)
        style.configure("TLabelframe.Label", background=self.COLOR_BG, foreground=self.COLOR_ACCENT)
        style.configure("TLabel", background=self.COLOR_BG, foreground=self.COLOR_BTN_FG)
        style.configure("TButton", background=self.COLOR_BTN_BG, foreground=self.COLOR_BTN_FG, borderwidth=0)
        style.map("TButton", background=[("active", self.COLOR_ACCENT)], foreground=[("active", self.COLOR_ACCENT_FG)])
        style.configure("TNotebook", background=self.COLOR_BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=self.COLOR_PANEL, foreground=self.COLOR_BTN_FG, padding=[10, 5])
        style.map("TNotebook.Tab", background=[("selected", self.COLOR_ACCENT)], foreground=[("selected", self.COLOR_ACCENT_FG)])
        style.configure("TEntry", fieldbackground=self.COLOR_ENTRY_BG, foreground="#ffffff")
        style.configure("TScrollbar", background=self.COLOR_PANEL, troughcolor=self.COLOR_BG, borderwidth=0, arrowcolor=self.COLOR_BTN_FG)

        self.root.configure(bg=self.COLOR_BG)

        # Create notebook for tabs
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create tabs
        self.setup_tab = ttk.Frame(self.notebook)
        self.users_tab = ttk.Frame(self.notebook)
        self.friends_tab = ttk.Frame(self.notebook)
        self.broadcast_tab = ttk.Frame(self.notebook)
        self.ai_tab = ttk.Frame(self.notebook)

        self.notebook.add(self.setup_tab, text="Setup")
        self.notebook.add(self.users_tab, text="Users & Friends")
        self.notebook.add(self.friends_tab, text="Friends Chat")
        self.notebook.add(self.broadcast_tab, text="Broadcast")
        self.notebook.add(self.ai_tab, text="FastAI Chat (Beta)")

        # Build UI
        self.build_setup_tab()
        self.build_users_tab()
        self.build_friends_tab()
        self.build_broadcast_tab()
        self.build_AI_tab()

        # Register callbacks
        self.fc.register_callback('server_started', self.on_server_started)
        self.fc.register_callback('server_stopped', self.on_server_stopped)
        self.fc.register_callback('connected_to_server', self.on_connected_to_server)
        self.fc.register_callback('disconnected_from_server', self.on_disconnected_from_server)
        self.fc.register_callback('registration_confirmed', self.on_registration_confirmed)
        self.fc.register_callback('friend_request_received', self.on_friend_request_received)
        self.fc.register_callback('friend_accepted', self.on_friend_accepted)
        self.fc.register_callback('friend_declined', self.on_friend_declined)
        self.fc.register_callback('private_message_received', self.on_private_message_received)
        self.fc.register_callback('broadcast_received', self.on_broadcast_received)
        self.fc.register_callback('users_list_received', self.on_users_list_received)
        self.fc.register_callback('system_message', self.on_system_message)

        if hasattr(self.ai, 'setup'):
            self.ai.setup()

    def build_setup_tab(self):
        """Build setup tab with username, real name, and server connection"""
        frame = ttk.LabelFrame(self.setup_tab, text="User Setup", padding=10)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Account info banner
        if self._user_number is not None:
            info_frame = ttk.Frame(frame)
            info_frame.grid(row=0, column=0, columnspan=3, sticky=tk.EW, pady=(0, 8))
            ttk.Label(
                info_frame,
                text=f"Logged in as: {self.fc.username}   |   User #{self._user_number}",
                font=("Arial", 10, "bold"), foreground=self.COLOR_ACCENT
            ).pack(anchor=tk.W)

        row_offset = 1 if self._user_number is not None else 0

        # Username (read-only after login)
        ttk.Label(frame, text="Username:").grid(row=row_offset, column=0, sticky=tk.W, pady=5)
        self.username_var = tk.StringVar(value=self.fc.username or "")
        ttk.Entry(frame, textvariable=self.username_var, width=30,
                  state='readonly' if self._user_number else 'normal').grid(
            row=row_offset, column=1, sticky=tk.EW, pady=5)

        # Real Name (read-only after login)
        ttk.Label(frame, text="Real Name:").grid(row=row_offset + 1, column=0, sticky=tk.W, pady=5)
        self.real_name_var = tk.StringVar(value=self.fc.real_name or "")
        ttk.Entry(frame, textvariable=self.real_name_var, width=30,
                  state='readonly' if self._user_number else 'normal').grid(
            row=row_offset + 1, column=1, sticky=tk.EW, pady=5)

        # Server connection section
        server_frame = ttk.LabelFrame(frame, text="Connect to Server", padding=10)
        server_frame.grid(row=row_offset + 2, column=0, columnspan=3, sticky=tk.EW, pady=10)

        ttk.Label(server_frame, text="Server IP:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.server_ip_var = tk.StringVar(value="127.0.0.1")
        server_ip_entry = ttk.Entry(server_frame, textvariable=self.server_ip_var, width=30)
        server_ip_entry.grid(row=0, column=1, sticky=tk.EW, pady=5)

        ttk.Label(server_frame, text="Port:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.server_port_var = tk.StringVar(value="9999")
        server_port_entry = ttk.Entry(server_frame, textvariable=self.server_port_var, width=30)
        server_port_entry.grid(row=1, column=1, sticky=tk.EW, pady=5)

        connect_btn_frame = ttk.Frame(server_frame)
        connect_btn_frame.grid(row=2, column=0, columnspan=2, pady=10)

        ttk.Button(connect_btn_frame, text="Connect to Server", command=self.connect_to_server).pack(side=tk.LEFT, padx=5)
        ttk.Button(connect_btn_frame, text="Disconnect", command=self.disconnect_from_server).pack(side=tk.LEFT, padx=5)

        self.connection_status_var = tk.StringVar(value="Disconnected")
        ttk.Label(connect_btn_frame, textvariable=self.connection_status_var, foreground="#ef4444").pack(side=tk.LEFT, padx=20)

        # Danger zone — delete account
        danger_frame = ttk.LabelFrame(frame, text="Danger Zone", padding=10)
        danger_frame.grid(row=row_offset + 4, column=0, columnspan=3, sticky=tk.EW, pady=10)
        tk.Button(
            danger_frame, text="Delete Account",
            bg="#dc2626", fg="white",
            activebackground="#b91c1c", activeforeground="white",
            font=("Arial", 9, "bold"), command=self._delete_account,
            relief=tk.FLAT, bd=0, padx=10, pady=4
        ).pack(anchor=tk.W)

        frame.columnconfigure(1, weight=1)

    def build_users_tab(self):
        """Build users and friend requests tab with side-by-side split layout"""
        main_frame = ttk.Frame(self.users_tab, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Left Column: Online Users
        left_col = ttk.Frame(main_frame)
        left_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        ttk.Label(left_col, text="Online Users:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        users_frame = ttk.Frame(left_col)
        users_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.users_listbox = tk.Listbox(users_frame, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, selectbackground=self.COLOR_ACCENT, selectforeground=self.COLOR_ACCENT_FG, borderwidth=0, highlightthickness=0)
        self.users_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar1 = ttk.Scrollbar(users_frame, command=self.users_listbox.yview)
        scrollbar1.pack(side=tk.RIGHT, fill=tk.Y)
        self.users_listbox.config(yscrollcommand=scrollbar1.set)

        action_frame = ttk.Frame(left_col)
        action_frame.pack(fill=tk.X, pady=5)

        ttk.Button(action_frame, text="Refresh Users", command=self.refresh_users).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(action_frame, text="Send Friend Request", command=self.send_friend_request).pack(side=tk.LEFT)

        # Right Column: Friend Requests
        right_col = ttk.Frame(main_frame)
        right_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        ttk.Label(right_col, text="Friend Requests:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        requests_frame = ttk.Frame(right_col)
        requests_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.requests_text = tk.Text(requests_frame, state=tk.DISABLED, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, borderwidth=0, highlightthickness=0)
        self.requests_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar2 = ttk.Scrollbar(requests_frame, command=self.requests_text.yview)
        scrollbar2.pack(side=tk.RIGHT, fill=tk.Y)
        self.requests_text.config(yscrollcommand=scrollbar2.set)

        request_btn_frame = ttk.Frame(right_col)
        request_btn_frame.pack(fill=tk.X, pady=5)

        ttk.Button(request_btn_frame, text="Accept Request", command=self.accept_friend_request).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(request_btn_frame, text="Decline Request", command=self.decline_friend_request).pack(side=tk.LEFT)

        self.selected_request_var = tk.StringVar()

    def build_friends_tab(self):
        """Build friends chat tab with side-by-side pane split layout"""
        main_frame = ttk.Frame(self.friends_tab, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Left Column: Friends List
        left_col = ttk.Frame(main_frame, width=220)
        left_col.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        ttk.Label(left_col, text="Your Friends:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        friends_frame = ttk.Frame(left_col)
        friends_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.friends_listbox = tk.Listbox(friends_frame, width=25, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, selectbackground=self.COLOR_ACCENT, selectforeground=self.COLOR_ACCENT_FG, borderwidth=0, highlightthickness=0)
        self.friends_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar1 = ttk.Scrollbar(friends_frame, command=self.friends_listbox.yview)
        scrollbar1.pack(side=tk.RIGHT, fill=tk.Y)
        self.friends_listbox.config(yscrollcommand=scrollbar1.set)

        ttk.Button(left_col, text="Open Chat Window", command=self.open_chat_window).pack(fill=tk.X, pady=5)

        # Right Column: Main Chat Panel
        right_col = ttk.Frame(main_frame)
        right_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        ttk.Label(right_col, text="Chat Messages:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        chat_display_frame = ttk.Frame(right_col)
        chat_display_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.chat_display = tk.Text(chat_display_frame, state=tk.DISABLED, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, borderwidth=0, highlightthickness=0)
        self.chat_display.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar2 = ttk.Scrollbar(chat_display_frame, command=self.chat_display.yview)
        scrollbar2.pack(side=tk.RIGHT, fill=tk.Y)
        self.chat_display.config(yscrollcommand=scrollbar2.set)

        ttk.Label(right_col, text="Message:", font=("Arial", 9)).pack(anchor=tk.W, pady=2)
        self.private_message_input = tk.Text(right_col, height=3, bg=self.COLOR_ENTRY_BG, fg="#ffffff", insertbackground="#ffffff", borderwidth=0, highlightthickness=0)
        self.private_message_input.pack(fill=tk.X, pady=5)

        msg_button_frame = ttk.Frame(right_col)
        msg_button_frame.pack(fill=tk.X, pady=5)

        ttk.Button(msg_button_frame, text="Send Private Message", command=self.send_private_message).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(msg_button_frame, text="Refresh Messages", command=self.refresh_private_messages).pack(side=tk.LEFT)

    def build_broadcast_tab(self):
        """Build broadcast tab"""
        frame = ttk.LabelFrame(self.broadcast_tab, text="Broadcast Messages (Auto-Encrypted)", padding=10)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Broadcast display
        ttk.Label(frame, text="Broadcast Messages:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=5)

        broadcast_display_frame = ttk.Frame(frame)
        broadcast_display_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.broadcast_text = tk.Text(broadcast_display_frame, height=12, state=tk.DISABLED, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, borderwidth=0, highlightthickness=0)
        self.broadcast_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(broadcast_display_frame, command=self.broadcast_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.broadcast_text.config(yscrollcommand=scrollbar.set)

        # Message input
        ttk.Label(frame, text="Message:", font=("Arial", 9)).pack(anchor=tk.W, pady=2)
        self.broadcast_input = tk.Text(frame, height=3, bg=self.COLOR_ENTRY_BG, fg="#ffffff", insertbackground="#ffffff", borderwidth=0, highlightthickness=0)
        self.broadcast_input.pack(fill=tk.X, pady=5)

        ttk.Label(frame, text="Encryption: ON (Server Controlled - Cannot Be Changed)", foreground="#22c55e", font=("Arial", 9, "bold")).pack(anchor=tk.W, pady=2)

        button_frame = ttk.Frame(frame)
        button_frame.pack(fill=tk.X, pady=10)

        ttk.Button(button_frame, text="Send Broadcast to Everyone", command=self.send_broadcast).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Refresh Broadcasts", command=self.refresh_broadcasts).pack(side=tk.LEFT, padx=5)

    def build_AI_tab(self):
        """Build AI tab with model selection, chat screen, and media controls."""
        frame = ttk.LabelFrame(self.ai_tab, text="FastAI Chat & Media Tools", padding=10)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- Model Toggle Bar ---
        top_bar = tk.Frame(frame, bg=self.COLOR_PANEL, pady=4)
        top_bar.pack(fill=tk.X, pady=(0, 5))

        model_name = getattr(self.ai, 'model', 'Default')
        self.model_btn = tk.Button(
            top_bar,
            text=f"Model: {model_name}",
            command=self.toggle_ai_model,
            bg=self.COLOR_BTN_BG,
            fg=self.COLOR_BTN_FG,
            activebackground=self.COLOR_ACCENT,
            activeforeground=self.COLOR_ACCENT_FG,
            relief=tk.FLAT,
            font=("Arial", 9, "bold"),
            padx=8,
            pady=2
        )
        self.model_btn.pack(side=tk.LEFT, padx=5)

        ttk.Label(
            top_bar,
            text="Encryption: ON (Server Controlled)",
            foreground="#22c55e",
            font=("Arial", 9, "bold")
        ).pack(side=tk.RIGHT, padx=5)

        # --- AI Chat Display Frame ---
        AI_display_frame = ttk.Frame(frame)
        AI_display_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.AI_text = scrolledtext.ScrolledText(
            AI_display_frame,
            height=12,
            wrap=tk.WORD,
            font=("Arial", 10),
            state=tk.DISABLED,
            bg=self.COLOR_CHAT_BG,
            fg=self.COLOR_BOT_TXT,
            insertbackground="#ffffff",
            relief=tk.FLAT,
            highlightthickness=0
        )
        self.AI_text.pack(fill=tk.BOTH, expand=True)

        # Chat text tags for user alignment (right) and bot alignment (left)
        self.AI_text.tag_configure("user", justify="right", rmargin=15, lmargin1=80, lmargin2=80, foreground=self.COLOR_USER_TXT)
        self.AI_text.tag_configure("bot", justify="left", lmargin1=15, lmargin2=15, rmargin=80, foreground=self.COLOR_BOT_TXT)
        self.AI_text.tag_configure("system", justify="center", foreground=self.COLOR_SYS_TXT)

        self.append_ai_chat("bot", "Hello! FastAI is ready to assist you.")

        # --- Message Input Area ---
        ttk.Label(frame, text="Message / Prompt:", font=("Arial", 9)).pack(anchor=tk.W, pady=(5, 2))
        self.AI_text_input = tk.Entry(
            frame,
            font=("Arial", 11),
            bg=self.COLOR_ENTRY_BG,
            fg="#ffffff",
            insertbackground="#ffffff",
            relief=tk.FLAT,
            bd=5
        )
        self.AI_text_input.pack(fill=tk.X, pady=5)
        self.AI_text_input.bind("<Return>", lambda event: self.handle_ai_text_prompt())

        # --- Bottom Action Button Bar ---
        button_frame = tk.Frame(frame, bg=self.COLOR_PANEL, pady=5)
        button_frame.pack(fill=tk.X, pady=(5, 0))

        btn_kwargs = {
            "font": ("Arial", 11),
            "width": 3,
            "bg": self.COLOR_BTN_BG,
            "fg": self.COLOR_BTN_FG,
            "activebackground": self.COLOR_ACCENT,
            "activeforeground": self.COLOR_ACCENT_FG,
            "relief": tk.FLAT,
            "bd": 0
        }

        # Media Action Icons connected directly to self.ai methods
        tk.Button(button_frame, text="🖼️", command=self.handle_ai_image_prompt, **btn_kwargs).pack(side=tk.LEFT, padx=2)
        tk.Button(button_frame, text="🎨", command=self.handle_ai_image_generation, **btn_kwargs).pack(side=tk.LEFT, padx=2)
        tk.Button(button_frame, text="🎙️", command=self.handle_ai_voice_generation, **btn_kwargs).pack(side=tk.LEFT, padx=2)
        tk.Button(button_frame, text="🎥", command=self.handle_ai_video_prompt, **btn_kwargs).pack(side=tk.LEFT, padx=2)

        # Primary Send Button
        tk.Button(
            button_frame,
            text="Send Prompt",
            command=self.handle_ai_text_prompt,
            bg=self.COLOR_ACCENT,
            fg=self.COLOR_ACCENT_FG,
            activebackground="#0369a1",
            activeforeground="#ffffff",
            font=("Arial", 9, "bold"),
            relief=tk.FLAT,
            padx=10
        ).pack(side=tk.RIGHT, padx=5)

    def _delete_account(self):
        """Delete the currently logged-in account."""
        username = self.fc.username
        if not username or not accounts_api.is_logged_in():
            messagebox.showwarning("No Account", "No account is currently logged in.")
            return

        confirmed = messagebox.askyesno(
            "Delete Account",
            f"Are you sure you want to permanently delete the account '{username}'?\n\nThis cannot be undone.",
            icon='warning'
        )
        if not confirmed:
            return

        # The accounts server only deletes an account for someone who knows its password
        password = simpledialog.askstring(
            "Delete Account", "Enter your password to confirm:", show='*', parent=self.root)
        if not password:
            return

        try:
            result = accounts_api.delete_account(password)
            if not result.get('ok'):
                messagebox.showerror("Error", result.get('error', 'Failed to delete account.'))
                return

            # Disconnect from server gracefully
            try:
                self.fc.disconnect_from_server()
            except Exception:
                pass

            messagebox.showinfo("Account Deleted", f"Account '{username}' has been deleted.")
            self.root.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete account:\n{e}")

    def set_username(self):
        """Set username"""
        try:
            username = self.username_var.get()
            self.fc.set_username(username)
            messagebox.showinfo("Success", f"Username set to: {username}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def set_real_name(self):
        """Set real name"""
        try:
            real_name = self.real_name_var.get()
            self.fc.set_real_name(real_name)
            messagebox.showinfo("Success", f"Real name set to: {real_name}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def start_local_server(self):
        """Start local server"""
        try:
            ip = self.listen_ip_var.get()
            port = int(self.listen_port_var.get())
            self.fc.set_server_address(ip, port)
            if self.fc.start_local_server():
                messagebox.showinfo("Success", f"Server started on {ip}:{port}")
                self.server_status_var.set(f"Server: Running ({ip}:{port})")
            else:
                messagebox.showerror("Error", "Failed to start server")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def stop_local_server(self):
        """Stop local server"""
        if self.fc.stop_local_server():
            messagebox.showinfo("Success", "Server stopped")
            self.server_status_var.set("Server: Stopped")
        else:
            messagebox.showerror("Error", "Server is not running")

    def connect_to_server(self):
        """Connect to server"""
        try:
            ip = self.server_ip_var.get()
            port = int(self.server_port_var.get())

            def do_connect():
                if self.fc.connect_to_server(ip, port):
                    self.root.after(0, lambda: self.connection_status_var.set("Connected"))
                    self.root.after(0, lambda: messagebox.showinfo("Success", "Connected to server"))
                else:
                    reason = self.fc.last_error or "Failed to connect"
                    self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to connect:\n{reason}"))

            thread = threading.Thread(target=do_connect, daemon=True)
            thread.start()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def disconnect_from_server(self):
        """Disconnect from server"""
        if self.fc.disconnect_from_server():
            self.connection_status_var.set("Disconnected")
            messagebox.showinfo("Success", "Disconnected from server")
        else:
            messagebox.showerror("Error", "Not connected")

    def refresh_users(self):
        """Refresh online users list"""
        self.fc.request_users_list()

    def send_friend_request(self):
        """Send friend request"""
        selection = self.users_listbox.curselection()
        if selection:
            username = self.users_listbox.get(selection[0])
            if username != self.fc.username:
                self.fc.send_friend_request(username)
                messagebox.showinfo("Success", f"Friend request sent to {username}")
            else:
                messagebox.showwarning("Warning", "Cannot friend yourself")
        else:
            messagebox.showwarning("Warning", "Please select a user")

    def accept_friend_request(self):
        """Accept friend request"""
        from_user = simpledialog.askstring("Accept Request", "Enter username of the person whose request to accept:")
        if from_user:
            self.fc.respond_to_friend_request(from_user, True)
            self.refresh_friends()

    def decline_friend_request(self):
        """Decline friend request"""
        from_user = simpledialog.askstring("Decline Request", "Enter username of the person whose request to decline:")
        if from_user:
            self.fc.respond_to_friend_request(from_user, False)

    def refresh_friends(self):
        """Refresh friends list"""
        self.friends_listbox.delete(0, tk.END)
        friends_data = getattr(self.fc, 'friends', [])
        if isinstance(friends_data, dict):
            friends_data = list(friends_data.keys())
        for friend in friends_data:
            self.friends_listbox.insert(tk.END, friend)

    def toggle_ai_model(self):
        if hasattr(self.ai, 'setComplex'):
            new_model = self.ai.setComplex()
        elif hasattr(self.ai, 'toggle_model'):
            new_model = self.ai.toggle_model()
        else:
            new_model = getattr(self.ai, 'model', 'Default')

        self.model_btn.config(text=f"Model: {new_model}")
        if hasattr(self.ai, 'client') and hasattr(self.ai.client, 'chats'):
            self.ai.chat = self.ai.client.chats.create(model=new_model, config=getattr(self.ai, 'config', None))
        self.append_ai_chat("system", f"--- Active model updated to {new_model} ---")

    def append_ai_chat(self, sender_type, text):
        self.AI_text.config(state=tk.NORMAL)
        if sender_type == "user":
            self.AI_text.insert(tk.END, f"You\n{text}\n\n", "user")
        elif sender_type == "bot":
            self.AI_text.insert(tk.END, f"FastAI\n{text}\n\n", "bot")
        else:
            self.AI_text.insert(tk.END, f"{text}\n\n", "system")
        self.AI_text.config(state=tk.DISABLED)
        self.AI_text.yview(tk.END)

    def handle_ai_text_prompt(self):
        prompt = self.AI_text_input.get().strip()
        if not prompt:
            return
        self.AI_text_input.delete(0, tk.END)
        self.append_ai_chat("user", prompt)
        try:
            reply = self.ai.ask(prompt)
            self.append_ai_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Failed: {e}")

    def handle_ai_image_prompt(self):
        prompt = self.AI_text_input.get().strip() or "Describe this image."
        self.AI_text_input.delete(0, tk.END)
        self.append_ai_chat("user", f"[Sent Image] Prompt: '{prompt}'")
        try:
            reply = self.ai.read(prompt)
            if reply != "No file selected":
                self.append_ai_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Image analysis failed: {e}")

    def handle_ai_image_generation(self):
        prompt = self.AI_text_input.get().strip()
        if not prompt:
            messagebox.showinfo("Input Required", "Enter an image generation prompt in the text box first.")
            return
        self.AI_text_input.delete(0, tk.END)
        self.append_ai_chat("user", f"[Generate Image] {prompt}")
        try:
            path = self.ai.generate_image(prompt)
            self.append_ai_chat("bot", f"Image generated & saved to: '{path}'" if path else "Generation failed.")
        except Exception as e:
            messagebox.showerror("API Error", f"Image generation failed: {e}")

    def handle_ai_voice_generation(self):
        prompt = self.AI_text_input.get().strip()
        if not prompt:
            messagebox.showinfo("Input Required", "Enter text to generate voice speech.")
            return
        self.AI_text_input.delete(0, tk.END)
        self.append_ai_chat("user", f"[Voice Request] {prompt}")
        try:
            res = self.ai.generate_voice(prompt)
            self.append_ai_chat("bot", f"Voice output saved: {res}")
        except Exception as e:
            messagebox.showerror("API Error", f"Voice generation failed: {e}")

    def handle_ai_video_prompt(self):
        prompt = self.AI_text_input.get().strip() or "Summarize this video."
        self.AI_text_input.delete(0, tk.END)
        self.append_ai_chat("user", f"[Sent Video] Prompt: '{prompt}'")
        try:
            reply = self.ai.analyze_video(prompt)
            if reply != "No video file selected":
                self.append_ai_chat("bot", reply)
        except Exception as e:
            messagebox.showerror("API Error", f"Video analysis failed: {e}")

    def open_chat_window(self):
        """Open private chat window with selected friend"""
        selection = self.friends_listbox.curselection()
        if selection:
            friend = self.friends_listbox.get(selection[0])
            if friend not in self.chat_windows or not self.chat_windows[friend].winfo_exists():
                self.chat_windows[friend] = self.create_chat_window(friend)
            else:
                self.chat_windows[friend].lift()
        else:
            messagebox.showwarning("Warning", "Please select a friend")

    def create_chat_window(self, friend_username):
        """Create a private chat window"""
        chat_window = tk.Toplevel(self.root)
        chat_window.title(f"Chat with {friend_username} (Encrypted)")
        chat_window.geometry("500x400")
        chat_window.configure(bg=self.COLOR_BG)

        # Chat display
        ttk.Label(chat_window, text=f"Chat with {friend_username}", font=("Arial", 10, "bold")).pack(anchor=tk.W, padx=10, pady=5)

        chat_frame = ttk.Frame(chat_window)
        chat_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        chat_text = tk.Text(chat_frame, height=12, state=tk.DISABLED, bg=self.COLOR_CHAT_BG, fg=self.COLOR_BTN_FG, borderwidth=0, highlightthickness=0)
        chat_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(chat_frame, command=chat_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        chat_text.config(yscrollcommand=scrollbar.set)

        # Message input
        ttk.Label(chat_window, text="Message (Auto-Encrypted):", font=("Arial", 9)).pack(anchor=tk.W, padx=10)

        message_input = tk.Text(chat_window, height=3, bg=self.COLOR_ENTRY_BG, fg="#ffffff", insertbackground="#ffffff", borderwidth=0, highlightthickness=0)
        message_input.pack(fill=tk.X, padx=10, pady=5)

        def send():
            msg = message_input.get("1.0", tk.END).strip()
            if msg:
                self.fc.send_private_message(friend_username, msg)
                chat_text.config(state=tk.NORMAL)
                chat_text.insert(tk.END, f"You: {msg}\n")
                chat_text.config(state=tk.DISABLED)
                message_input.delete("1.0", tk.END)
            else:
                messagebox.showwarning("Warning", "Please enter a message")

        ttk.Button(chat_window, text="Send", command=send).pack(pady=10)

        # Store reference to chat text widget
        chat_window.chat_text = chat_text

        return chat_window

    def send_private_message(self):
        """Send private message"""
        selection = self.friends_listbox.curselection()
        if selection:
            friend = self.friends_listbox.get(selection[0])
            msg = self.private_message_input.get("1.0", tk.END).strip()
            if msg:
                self.fc.send_private_message(friend, msg)
                self.chat_display.config(state=tk.NORMAL)
                self.chat_display.insert(tk.END, f"You to {friend}: {msg}\n")
                self.chat_display.config(state=tk.DISABLED)
                self.private_message_input.delete("1.0", tk.END)
            else:
                messagebox.showwarning("Warning", "Please enter a message")
        else:
            messagebox.showwarning("Warning", "Please select a friend")

    def send_broadcast(self):
        """Send broadcast message"""
        msg = self.broadcast_input.get("1.0", tk.END).strip()
        if msg:
            self.fc.send_broadcast(msg)
            self.broadcast_text.config(state=tk.NORMAL)
            self.broadcast_text.insert(tk.END, f"[You]: {msg}\n")
            self.broadcast_text.see(tk.END)
            self.broadcast_text.config(state=tk.DISABLED)
            self.broadcast_input.delete("1.0", tk.END)
            messagebox.showinfo("Success", "Broadcast sent to everyone (Encrypted by Server)")
        else:
            messagebox.showwarning("Warning", "Please enter a message")

    def refresh_broadcasts(self):
        """Refresh broadcasts display"""
        self.broadcast_text.config(state=tk.NORMAL)
        self.broadcast_text.see(tk.END)
        self.broadcast_text.config(state=tk.DISABLED)

    def refresh_private_messages(self):
        """Refresh private messages display"""
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    # Callbacks
    def on_server_started(self, data):
        """Handle server started"""
        self.server_status_var.set(f"Server: Running (:{data.get('port', '')})")

    def on_server_stopped(self, data):
        """Handle server stopped"""
        self.server_status_var.set("Server: Stopped")

    def on_connected_to_server(self, data):
        """Handle connected to server"""
        self.connection_status_var.set("Connected")
        self.add_status_message(f"Connected to {data.get('host')}:{data.get('port')}")

    def on_registration_confirmed(self, data):
        """Server confirmed registration — populate friends list from server data (network thread)"""
        def _update():
            self.refresh_friends()
            friends_data = getattr(self.fc, 'friends', [])
            if isinstance(friends_data, dict):
                friends_data = list(friends_data.keys())
            if len(friends_data):
                self.add_status_message(f"Friends list restored: {', '.join(friends_data)}")
        self.root.after(0, _update)

    def on_disconnected_from_server(self, data):
        """Handle disconnected from server"""
        self.connection_status_var.set("Disconnected")
        self.add_status_message("Disconnected from server")

    def on_friend_request_received(self, data):
        """Handle friend request (called from network thread)"""
        from_user = data.get('from_user')
        def _update():
            self.requests_text.config(state=tk.NORMAL)
            self.requests_text.insert(tk.END, f"Friend request from: {from_user}\n")
            self.requests_text.config(state=tk.DISABLED)
            messagebox.showinfo("Friend Request", f"{from_user} sent you a friend request!")
        self.root.after(0, _update)

    def on_friend_accepted(self, data):
        """Handle friend accepted (called from network thread)"""
        friend = data.get('friend')
        def _update():
            messagebox.showinfo("Friend Added", f"You are now friends with {friend}")
            self.refresh_friends()
        self.root.after(0, _update)

    def on_friend_declined(self, data):
        """Handle friend declined (called from network thread)"""
        friend = data.get('friend')
        self.root.after(0, lambda: messagebox.showinfo("Request Declined", f"{friend} declined your friend request"))

    def on_private_message_received(self, data):
        """Handle private message (called from network thread)"""
        from_user = data.get('from')
        message = data.get('message')
        def _update():
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.insert(tk.END, f"{from_user}: {message}\n")
            self.chat_display.see(tk.END)
            self.chat_display.config(state=tk.DISABLED)
            if from_user in self.chat_windows and self.chat_windows[from_user].winfo_exists():
                self.chat_windows[from_user].chat_text.config(state=tk.NORMAL)
                self.chat_windows[from_user].chat_text.insert(tk.END, f"{from_user}: {message}\n")
                self.chat_windows[from_user].chat_text.see(tk.END)
                self.chat_windows[from_user].chat_text.config(state=tk.DISABLED)
        self.root.after(0, _update)

    def on_broadcast_received(self, data):
        """Handle broadcast message (called from network thread)"""
        from_user = data.get('from')
        message = data.get('message')
        if from_user == self.fc.username:
            return 0
        def _update():
            self.broadcast_text.config(state=tk.NORMAL)
            self.broadcast_text.insert(tk.END, f"[{from_user}]: {message}\n")
            self.broadcast_text.see(tk.END)
            self.broadcast_text.config(state=tk.DISABLED)
        self.root.after(0, _update)

    def on_users_list_received(self, data):
        """Handle users list (called from network thread)"""
        users = data.get('users', [])
        def _update():
            self.users_listbox.delete(0, tk.END)
            for user in users:
                if user != self.fc.username:
                    self.users_listbox.insert(tk.END, user)
        self.root.after(0, _update)

    def on_system_message(self, data):
        """Handle system message (called from network thread)"""
        message = data.get('message')
        def _update():
            self.broadcast_text.config(state=tk.NORMAL)
            self.broadcast_text.insert(tk.END, f"[SYSTEM]: {message}\n")
            self.broadcast_text.see(tk.END)
            self.broadcast_text.config(state=tk.DISABLED)
        self.root.after(0, _update)

    def add_status_message(self, message):
        """Add status message to broadcast tab"""
        self.broadcast_text.config(state=tk.NORMAL)
        self.broadcast_text.insert(tk.END, f">>> {message}\n")
        self.broadcast_text.config(state=tk.DISABLED)


def main():
    """Main entry point — show login window first, then the main app"""
    from login import LoginWindow

    app_icon.set_windows_app_id()
    login_root = tk.Tk(className=app_icon.WM_CLASS)
    login_root.resizable(False, False)

    def on_login_success(username, real_name, user_number):
        login_root.destroy()
        main_root = tk.Tk(className=app_icon.WM_CLASS)

        FastConnectGUI(main_root, username=username, real_name=real_name, user_number=user_number)
        main_root.mainloop()

    LoginWindow(login_root, on_login_success)
    login_root.mainloop()

if __name__ == '__main__':
    main()